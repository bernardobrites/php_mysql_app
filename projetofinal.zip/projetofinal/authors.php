<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible"
            content="IE=edge">
        <meta name="viewport"
            content="width=device-width, initial-scale=1.0">
        <title>clientes</title>
        <link rel="stylesheet"
            href="css/bootstrap.css" />
        <link rel="stylesheet"
            href="jquerypicker/jquery-ui.css" />

    <body>
        <div class="container">
            <div id="menu"></div>
            <div class="row">
            
                <div class="col-9">
                    <h3>Autores</h3>
                    <h4 id="msg"
                        style="color:red">
                        <?php
                        //  echo $_GET['msg'];
                       ?>
                    </h4>
                    <table class="table table-responsive table-striped table-bordered table-success">
                        <thead>
                            <td>Id</td>
                            <td>Nome</td>
                            <td>Pais</td>                            
                            <td>comandos</td>

                        </thead>
                        <tbody id="tb">
                            <?php
                            function del($id){
                                return "<a name='del' data-id='".$id."' class ='btn btn-danger' id='".$id."'>Del</a>";
                            }
                            function lnk($id){
                                return "<a href='authorsedit.php?id=".$id."'>".$id. "</a>";
                            }

                            include("cnn.php");
                            $stmt =$pdo -> query("select * from authors;");
                            $autores = $stmt ->fetchAll();
                            foreach($autores as $k =>$item){
                                echo "<tr>
                                <td>".lnk($item['Id'])."</td>
                                <td>".$item ['Name']."</td>
                                <td>".$item['Country']."</td>
                                <td>".del($item['Id'])."</td>
                                </tr>";

                            }

                            
                            ?>
                        </tbody>

                    </table>

                    <!-- Button trigger modal -->
                    <button type="button"
                        class="btn btn-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        Inserir Autor
                    </button>

                    <!-- Modal -->
                    <div class="modal fade"
                        id="exampleModal"
                        tabindex="-1"
                        aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title"
                                        id="exampleModalLabel">Inserir Autor</h5>
                                    <button type="button"
                                        class="btn-close"
                                        data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="#"
                                        method="post"
                                        enctype="application/x-www-form-urlencoded"
                                        id="frm">
                                        <div class="form-group">
                                            <label for="txtnome">Nome</label>
                                            <input type="text"
                                                name="txtnome"
                                                id="txtnome"
                                                class="form-control"
                                                placeholder="">
                                        </div>
                                        <div class="form-group">
                                            <label for="txtpais">Pais</label>
                                            <input type="text"
                                                name="txtpais"
                                                id="txtpais"
                                                class="form-control"
                                                placeholder="">
                                        </div>
                                    </form>

                                </div>
                                <div class="modal-footer">
                                    <button type="button"
                                        class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button id="btinsert"
                                        type="button"
                                        class="btn btn-primary">Insert</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <script src="js/jquery-3.6.0.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="jquerypicker/jquery-ui.js"></script>
        <script src="js2/js2/bootstrap-treeview.js"></script>
        <script>
        function init() {

            $("[name='del']").click(function(evt) {
                evt = evt ? evt : window.event;
                // alert($(evt.target).data('idcli'));

                $(evt.target).css({
                    "background-color": "blue"

                });
                $.ajax({
                    url: "deleteAuthors.php",
                    type: 'post',
                    dataType: 'json',
                    processData: true,
                    contentType: 'application/x-www-form-urlencoded',

                    data: {
                        Id: evt.target.id
                    },
                    success: function(dados) {
                        console.log(dados);
                        if (dados.msg == 1) {
                            $(evt.target).closest("tr").remove();
                            $("#msg").html("apagou");
                        }
                        if (dados.msg ==2300){
                            $("#msg").html("Autor não pode ser apagado porque tem livros");
                        }
                    
                    },  
                     error: function() {
                         alert("erro ");
                     }

                });


            });

        }

        function del($id) {
            return "<a name='del' data-id='" + $id + "' class ='btn btn-danger' id='" + $id + "'>Del</a>";
        }
        
        $(function(){

            $("#menu").load("menu.html");
            init();
            $("#btinsert").click(function(evt) {
                evt = evt ? evt : window.event;
                evt.preventDefault();
                //alert(evt.target.id);
                var frm = document.getElementById("frm");
                var formdata = new FormData(frm);
                for (var item of formdata) console.log(item);
                $.ajax({
                    url: 'insertAuthors.php',
                    method: 'post',
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    data: formdata,
                    success: function(dados) {
                        console.log(dados);
                        if (dados.msg == 1) {
                            let linha = "<tr><td>" + dados.Id + "</td><td>" + dados
                                .Name + "</td><td>" + dados.Country + "</td><td>" + dados
                                .idade + "</td><td>" + del(dados.Id) + "</td></tr>";
                            $("#tb").append(linha);
                            init();
                            $("#exampleModal").modal("hide");
                        }
                    },
                    error: function(err) {
                        alert(err);
                    }
                });
            });

        });
    
        </script>



    </body>

</html>
