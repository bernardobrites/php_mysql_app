<?php
$msg;
  try {

    $Id= $_POST['txtid'];
    $name= $_POST['txtnome'];
    $pais= $_POST['txtpais'];
    include ('cnn.php');
    $sql="update Authors set Name=:Name, Country=:Country where Id=:Id;";
    $stmt= $pdo->prepare($sql);
    $stmt->execute(["Name"=>$name,"Country"=>$pais, "Id"=>$Id] );
    $total = $stmt->rowCount();
    $msg=array("msg"=>$total);

  } catch (PDOException $e) {
      $msg= array("msg"=> $e->getMessage());
  }

  echo json_encode($msg);

?>