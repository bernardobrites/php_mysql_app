<?php  
 //login_success.php  
 session_start();  
 if(isset($_SESSION["username"]))  
 {  
      echo '<h3>Login Success, Welcome - '.$_SESSION["username"].'</h3>';  
      echo '<br /><br /><a href="logout.php">Logout</a>';  
      echo '<br /><br /><a href="authors.php">Principal</a>';  
 }  
 else  
 {  
      header("location:login.php");  
 }  


 ?>  

 <!DOCTYPE html>
 <html lang="en">
 <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login</title>
      <link  rel="stylesheet" href="css/bootstrap.css"/>
        <link  rel="stylesheet" href="jquerypicker/jquery-ui.css"/>   
 </head>
 <body>
      



 <script src="js/jquery-3.6.0.js"></script>
    <script src="js/bootstrap.js"></script>
 </body>
 </html>