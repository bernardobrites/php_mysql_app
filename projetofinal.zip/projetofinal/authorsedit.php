<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible"
            content="IE=edge">
        <meta name="viewport"
            content="width=device-width, initial-scale=1.0">
        <title>Editar Autor</title>
        <link rel="stylesheet"
            href="css/bootstrap.css"
            type="text/css" />
        <link rel="stylesheet"
            href="jquerypicker/jquery-ui.css" />

    <body>
        <?php 
           try {
               include ("cnn.php");
               $sql="select  * from Authors where Id=:Id;";
               $Id = $_GET['id'];
               $stmt=$pdo->prepare($sql);
               $stmt->execute(["Id"=>$Id]);
               $autor =$stmt->fetch();
           } catch (PDOException $e) {
               echo $e->getMessage();
           }
        
        ?>
        <div class="container">
            <div id="menu"></div>
            <div class="row">
                
                <div class="col-8">
                    <h3>Edição de um Autor</h3>
                    <form id="frm"
                        name="frm"
                        method="post">
                        <div class="form-group">
                            <label for="txtid">Id</label>
                            <input type="text"
                                name="txtid"
                                id="txtid"
                                class="form-control"
                                readonly="readonly"
                                value="<?php 
                                  echo ($autor !=NULL)?$autor['Id']:"";
                                ?>"
                                placeholder="">

                        </div>
                        <div class="form-group">
                            <label for="txtnome">nome</label>
                            <input type="text"
                                id="txtnome"
                                name="txtnome"
                                value="<?php 
                                  echo ($autor !=NULL)?$autor['Name']:"";
                                ?>"
                                class="form-control" />

                        </div>
                        <div class="form-group">
                            <label for="txtpais">Pais</label>
                            <input type="text"
                                name="txtpais"
                                id="txtpais"
                                value="<?php 
                                  echo ($autor !=NULL)?$autor['Country']:"";
                                ?>"
                                class="form-control"
                                readonly="readonly"
                                placeholder="">

                        </div>
                        <div class="form-group p-4">
                            <input name="btsave"
                                id="btsave"
                                class="btn btn-primary"
                                type="button"
                                value="Save">
                            &nbsp;&nbsp;
                            <input name="btcancel"
                                id="btcancel"
                                class="btn btn-danger"
                                type="button"
                                value="Cancel">
                        </div>

                    </form>
                </div>
            </div>

            <script src="js/jquery-3.6.0.js"></script>
            <script src="js/bootstrap.js"></script>
            <script src="jquerypicker/jquery-ui.js"></script>
            <script>
            $(function() {
                $("#menu").load("menu.html");
                
                $("#btcancel").click(function(evt) {
                    evt = evt ? evt : window.event;
                    window.location = document.referrer;
                });

                $("#btsave").click(function(evt) {
                    evt = evt ? evt : window.event;
                    evt.preventDefault();
                    var frm = document.getElementById("frm");
                    var formdata = new FormData(frm);
                    for (var item of formdata) console.log(item);
                    $.ajax({
                        url: 'authorsupdate.php',
                        method: 'post',
                        dataType: 'json',
                        processData: false,
                        contentType: false,
                        data: formdata,
                        success: function(dados) {
                            console.log(dados);
                            window.location =
                                "authors.php?msg=Registo Gravado com Sucesso";
                        },
                        error: function(err) {
                            alert(err);
                        }
                    });
                });

            });
            </script>
    </body>

</html>
