<?php
if(isset($_POST["Id"])){
 $Id=  $_POST["Id"];
 include ("cnn.php");
 try {
   $sql ="delete from Authors where Id=:Id";
    $stmt=$pdo->prepare($sql);
    $stmt->execute(["Id"=>$Id]);
    $total = $stmt->rowCount();
    $msg=array("msg"=>$total);
 } catch (PDOException $e ) {
     $msg=array("msg"=>$e->getCode());
 }

}else{
  $msg=array("msg"=>"erro");
}
echo json_encode($msg);
?>