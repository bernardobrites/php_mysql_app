<?php
$msg;
  try {
      if(isset($_POST['txtnome']) && isset($_POST['txtpais']) ){

        include ("cnn.php");
        $sql ="insert into Authors(Name,Country)values(:Name, :Country);";
        $stmt = $pdo->prepare($sql);
        $name=$_POST['txtnome'];
        $Country=$_POST['txtpais'];
        $stmt->execute(["Name"=>$name, "Country"=>$Country]);
        $total =$stmt->rowCount();
        $sql="SELECT LAST_INSERT_ID();";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $id= $stmt->fetchColumn();
        $sql="select * from Authors where Id=:Id;";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(["Id"=>$id]);
        $autor = $stmt->fetch();
        $msg=array("msg"=>$total, "Id"=>$autor['Id'], "Name"=>$autor['Name'], "Country"=>$autor['Country']);
      }else{
          $msg=array("msg"=>-1);
      }
  } catch (PDOException $e) {
     $msg= array("msg"=>$e->getMessage()); 
  }

  echo json_encode($msg);
?>