<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible"
            content="IE=edge">
        <meta name="viewport"
            content="width=device-width, initial-scale=1.0">
        <title>Editar Livro</title>
        <link rel="stylesheet"
            href="css/bootstrap.css" />
        <link rel="stylesheet"
            href="jquerypicker/jquery-ui.css" />

    <body>
        <?php 
        include 'cnn.php';
        $id=-1;
        $filename="";
    if($_SERVER['REQUEST_METHOD'] === 'POST'  &&   isset($_POST['submit'])){
         echo 'post';
          $id=$_POST['txtId'];
          $titulo = $_POST['txttitulo'];
          $name =$_FILES['fich']['name'];
          $size =$_FILES['fich']['size'];
          $type =$_FILES['fich']['type'];
          if(isset($_FILES['fich'])){
              preg_match("/image/", $type,$matches);
              if(count($matches)>0 && $size <300000){
                    $ext = pathinfo($name, PATHINFO_EXTENSION);
                    $filename = $id . "." .$ext; 
                    $destino = dirname(__DIR__) . "\\PROJETOFINAL\\fotos\\" .$filename;
                    echo $destino;
                    move_uploaded_file($_FILES['fich']['tmp_name'], $destino);
              }


          }

          $sql= "update books set Title=:Title, foto=:foto  where Id=:Id;";
           $stmt = $pdo->prepare($sql);
           $stmt->execute(["Title"=>$titulo, "foto"=>$filename, "Id"=>$id]);

    }else{
        echo 'get';
        $id=$_GET['id'];
        
    }
    
    $sql = "select  * from books where Id=:Id;";
    $stmt =$pdo->prepare($sql);
    $stmt->execute(["Id"=>$id]);
    $livro= $stmt->fetch(PDO::FETCH_ASSOC);

?>


        <div class="container">
            <div id="menu"></div>
            <div class="row">
               
                <div class="col-9">
                    <h3>Editar Livro</h3>
                    <h4 id="msg"
                        style="color:red">

                    </h4>
                    <form action="editbook.php"
                        method="post"
                        enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="txtId">Id</label>
                            <input type="text"
                                name="txtId"
                                id="txtId"
                                readonly="readonly"
                                value="<?php 
                                   if(isset($livro['Id'])){
                                       echo $livro['Id'];
                                   }
                                ?>"
                                class="form-control"
                                placeholder="">
                        </div>

                        <div class="form-group">
                            <label for="txttitulo">Titulo</label>
                            <input type="text"
                                name="txttitulo"
                                id="txttitulo"
                                value="<?php 
                                   if(isset($livro['Titulo'])){
                                       echo $livro['Titulo'];
                                   }
                                ?>"
                                class="form-control"
                                placeholder="">
                        </div>

                       
                        

                        <div class="form-group m-2">
                            <img src="<?php
                                if(isset($livro['foto'])){
                                       echo   "fotos/" .   $livro['foto'];
                                }else{
                                     echo   "fotos/noimage.png";
                                }
                            
                            ?>"
                                alt=""
                                class=""
                                style="width: 300px;display: block;">
                        </div>

                        <div class="form-group">
                            <label for="fich">Escolher Foto:</label>
                            <input type="file"
                                class="form-control-file"
                                name="fich"
                                id="fich"
                                placeholder=""
                                value="Clicar">

                        </div>

                        <button type="submit"
                            name="submit"
                            class="btn btn-primary">Submit</button>


                    </form>

                </div>
            </div>
        </div>
        <script src="js/jquery-3.6.0.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="jquerypicker/jquery-ui.js"></script>
        <script>
        $(function() {
       
            $("#menu").load("menu.html"); // carregar o menu para não ter de se fazer um menu novo em todas as paginas
        });
        </script>



    </body>

</html>
